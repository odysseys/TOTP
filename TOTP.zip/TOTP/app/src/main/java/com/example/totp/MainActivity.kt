package com.example.totp

import android.Manifest
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import java.nio.ByteBuffer
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.experimental.and
import kotlin.math.pow
import java.util.*
import android.os.CountDownTimer
import org.apache.commons.codec.binary.Base32
import android.content.pm.PackageManager
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import java.io.IOException
import com.google.zxing.integration.android.IntentIntegrator
import android.content.Intent
import android.net.Uri




class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var passWord:TextView
    private lateinit var countDown: TextView
    private lateinit var key: TextView
    private lateinit var userName: TextView
    private lateinit var otpType: TextView
    private lateinit var scanBtn: Button
    private lateinit var qrCode: TextView
    var base32key = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getPermissionsCamera()
        passWord = findViewById(R.id.PassWord) //TOTP密碼TextView
        key = findViewById(R.id.Key) //TOTP key TextView
        countDown = findViewById(R.id.CountDown) //計時器秒數TextView
        userName = findViewById(R.id.UserName) //User Name TextView
        otpType = findViewById(R.id.OtpType) //Issuer TextView
        scanBtn = findViewById(R.id.ScanBtn) //掃描QR code按鈕
        qrCode = findViewById(R.id.QRcode) //顯示QR code內容
        scanBtn.setOnClickListener(this)
        updateTOTPHandler.postDelayed(updateTimerThread, 0)//每到系統時間0/30秒時重複執行

        base32key = intent.getStringExtra("key")
        userName.text = intent.getStringExtra("name")
        val memberList = ArrayList<CardMember>()
        memberList.add(CardMember(1, "Name 1", "123456"))
        memberList.add(CardMember(2, "Name 2", "789012"))
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ScanBtn -> {
                if (ActivityCompat.checkSelfPermission(applicationContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    return
                }
                try {
                    var scanIntegrator = IntentIntegrator(this)
                    scanIntegrator.setPrompt("請掃描")
                    scanIntegrator.setTimeout(300000)
                    scanIntegrator.setOrientationLocked(false)
                    scanIntegrator.initiateScan()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
            else -> {
            }
        }
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
        val scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent)
        if (scanningResult != null) {
            if (scanningResult.contents != null) {
                val scanContent = scanningResult.contents
                if (scanContent != "") {
                    //Toast.makeText(applicationContext, "掃描內容: $scanContent", Toast.LENGTH_LONG).show()
                    qrCode.text = scanContent
                    val uri = Uri.parse(scanContent)
                    val secret = uri.getQueryParameter("secret")
                    val otpMethod = uri.host
                    val uName = uri.path!!.substring(1) //remove first '/'
                    Toast.makeText(applicationContext, "UserName: $uName", Toast.LENGTH_LONG).show()
                    if(!secret.isNullOrBlank())
                    {
                        base32key = secret
                        key.text = "Key: " + secret
                        updateTOTPHandler.post(updateTimerThread) //更新PassWord
                    }
                    otpType.text = "OTP Type: " + otpMethod
                    userName.text = "User Name: " + uName
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, intent)
            Toast.makeText(applicationContext, "發生錯誤", Toast.LENGTH_LONG).show()
        }
    }

    val updateTOTPHandler = android.os.Handler()
    private val updateTimerThread = object : Runnable {
        override fun run() {
            key.text = "Key: " + base32key
            //val key: ByteArray = ubyteArrayOf(0x00U,0x44U,0x32U,0x14U,0xC7U,0x42U,0x54U,0xB6U,0x35U,0xCFU,0x84U,0x65U,0x3AU,0x56U,0xD7U,0xC6U,0x75U,0xBEU,0x77U,0xDFU).toByteArray()
            val codeString = genTotp(base32key) //產生TOTP
            passWord.text = codeString
            Log.d("code","TOTP=" + codeString)
            val counterTime = 30000 - System.currentTimeMillis().rem(30000) //下次更新的時間間隔
            var countDownVal = counterTime.div(1000) + 2 //計時器開始的秒數 +2: shift from -1~28 to 1~30
            val timer = object: CountDownTimer(counterTime, 1000) {
                override fun onTick(millisUntilFinished: Long)
                {
                    countDownVal--
                    countDown.text = countDownVal.toString()
                }
                override fun onFinish() {}
            }
            timer.start()
            Log.d("code","System.currentTimeMillis().rem(30000)=" + System.currentTimeMillis().rem(30000))
            updateTOTPHandler.postDelayed(this, counterTime)
        }
    }

    private fun genTotp(base32key: String) : String {
        val time_period = Date(System.currentTimeMillis()) //ms from 1970/1/1 UTC
        val time_step = 30000 //ms
        var counter:Long
        if(time_step == 0) counter = 0 else counter = (time_period.time.div(time_step)) //避免除數＝0
        //Log.d("code", "time_period=" + time_period.time.toInt() + ", counter=" + counter)
        val message = ByteBuffer.allocate(8).putLong(counter).array() //設定seed
        val codeDigits = 6 //設定輸出密碼為6位數
        val mac = Mac.getInstance("HmacSHA1")
        val key: ByteArray = base32key.base32Decode() //把base32 key decode成byte array
        val secretKey = SecretKeySpec(key, mac.algorithm)
        mac.init(secretKey)
        val hash = mac.doFinal(message)
        val offset = hash.last().and(0x0F).toInt()
        var binaryInt:Int = 0
        for(i in 0..3){
            binaryInt = binaryInt shl 8
            //Log.d("code","binaryn1=" + binaryInt + ", i=" + i)
            if(i==0){
                binaryInt = binaryInt or (hash[offset + i] and 0x7F.toByte()).toInt()
            }
            else{
                binaryInt = binaryInt or ((hash[offset + i] and 0xFF.toByte()).toInt() shl 24 ushr 24) //避免負數時高位補1
                //Log.d("code", "hash[offset + i] and 0xFF=" + ((hash[offset + i] and 0xFF.toByte()).toInt() shl 24 ushr 24))
            }
            //Log.d("code","binaryn2=" + binaryInt + ", i=" + i)
        }
        val codeInt = binaryInt.rem(10.0.pow(codeDigits).toInt())
        var codeString = codeInt.toString()
        if(codeString.length < codeDigits)
        {
            codeString = "0".repeat(codeDigits - codeString.length) + codeString
        }
        return codeString
    }

    fun String.base32Decode(): ByteArray {
        val base32Codec = Base32()
        return base32Codec.decode(this)
    }

    fun getPermissionsCamera(){
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),1)
        }
    }
}