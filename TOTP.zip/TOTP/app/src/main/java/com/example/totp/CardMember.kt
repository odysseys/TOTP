package com.example.totp

import android.content.Entity

class CardMember {
    private var id: Int = 0
    private var name: String? = null
    private var password: String? = null

    constructor(id: Int, name: String, password: String) {
        this.id = id
        this.name = name
        this.password = password
    }

    fun getId(): Int {
        return id
    }

    fun setId(id: Int) {
        this.id = id
    }

    fun getName(): String? {
        return name
    }

    fun setName(name: String) {
        this.name = name
    }

    fun getPassword(): String? {
        return password
    }

    fun setPassword(password: String) {
        this.password = password
    }
}